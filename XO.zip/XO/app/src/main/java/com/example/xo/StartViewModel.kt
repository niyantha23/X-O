package com.example.xo

import androidx.lifecycle.ViewModel

class StartViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
